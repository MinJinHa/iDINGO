makeHubTable <- function(dat.tab, tab.length){
  tab <- dat.tab[order(dat.tab$freq, decreasing=TRUE),]
  tab <- tab[1:tab.length,]
  rownames(tab) <- NULL
  colnames(tab) <- c("Gene", "Edges")
  return(tab)
}

makeCorTable <- function(fit, threshType, thresh) {
  if (threshType == "diff.score"){
    cor.data <- data.frame(gene1 = fit$genepair$gene1,
                           gene2 = fit$genepair$gene2,
                           R1 = fit$R1,
                           R2 = fit$R2,
                           ds = fit$diff.score,
                           p.val = fit$p.val,
                           conserved = ifelse(fit$R1 * fit$R2 > 0, yes = 1, no = 2),
                           ds.col = ifelse(fit$diff.score > thresh,
                                           yes = "red",
                                           no = ifelse(fit$diff.score < -(thresh), yes = "blue", no = "grey")))
  } else {
    cor.data <- data.frame(gene1 = fit$genepair$gene1,
                           gene2 = fit$genepair$gene2,
                           R1 = fit$R1,
                           R2 = fit$R2,
                           ds = fit$diff.score,
                           p.val = fit$p.val,
                           conserved = ifelse(fit$R1 * fit$R2 > 0, yes = 1, no = 2),
                           ds.col = ifelse(fit$p.val < thresh,
                                           yes = ifelse(fit$diff.score > 0, yes = "red", no = "blue"),
                                           no = "grey"))
  }
  
}

read.compare.datasets <- function(file, prev.dataset){
  new.dataset <- read.table(file = file, sep = "", row.names = 1)
  if (dim(new.dataset)[2] != dim(prev.dataset)[2]){
    stop("ERROR: Number of samples in the data sets are not equal.")
  } else if (any(colnames(new.dataset) != colnames(prev.dataset))) {
    colnames(new.dataset) <- colnames(prev.dataset)
    cat("Data sets do not have the same sample (column) names. This should be checked.")
    return(new.dataset)
  } else{
    return(new.dataset)
  }
}
